package com.intelitune.nwms.material;

import java.util.ArrayList;
import java.util.List;

import com.intelitune.nwms.model.UnitPackagePairState;

import net.sf.click.control.Option;
import net.sf.click.control.Select;

public class DeminationSelect extends Select {

	private static final long serialVersionUID = 1L;
	
	public final List LIST_UNITPACKAGESTATESELECT = new ArrayList();
	  
	  {
	    	List listCurrency = new ArrayList();
	    	LIST_UNITPACKAGESTATESELECT.add(new Option("1","1"));
    		LIST_UNITPACKAGESTATESELECT.add(new Option("2","2"));
    		LIST_UNITPACKAGESTATESELECT.add(new Option("3","3"));
	    }
	  
	  public DeminationSelect(String name) {
	        super(name);
	        setOptionList(LIST_UNITPACKAGESTATESELECT);
	    }

	    /**
	     * Create the Investment option Select control.
	     */
	    public DeminationSelect() {
	        super();
	        setOptionList(LIST_UNITPACKAGESTATESELECT);
	    }
}
