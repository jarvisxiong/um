package com.intelitune.nwms.material;

public class MaterialMappingModel {
	private int column;
	private String value;
	public int getColumn() {
		return column;
	}
	public void setColumn(int column) {
		this.column = column;
	}
	public String getValue() {
		return value;
	}
	public void setValue(String value) {
		this.value = value;
	}
	
	

}
