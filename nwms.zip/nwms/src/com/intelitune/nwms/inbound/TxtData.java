package com.intelitune.nwms.inbound;

public class TxtData {
    private String job_id;
    private String bin_code;
    private String product_code;
    private String sn;
    private float qty;
	public String getJob_id() {
		return job_id;
	}
	public void setJob_id(String job_id) {
		this.job_id = job_id;
	}
	public String getBin_code() {
		return bin_code;
	}
	public void setBin_code(String bin_code) {
		this.bin_code = bin_code;
	}
	public String getProduct_code() {
		return product_code;
	}
	public void setProduct_code(String product_code) {
		this.product_code = product_code;
	}
	public String getSn() {
		return sn;
	}
	public void setSn(String sn) {
		this.sn = sn;
	}
	public float getQty() {
		return qty;
	}
	public void setQty(float qty) {
		this.qty = qty;
	}
    
    
}
