package com.intelitune.nwms.inbound;

import com.intelitune.nwms.model.Invoice;
import com.intelitune.nwms.model.ItemType;
import com.intelitune.nwms.model.UnitPackage;
import com.intelitune.nwms.model.Warehouse;

public class TableInbound {
	private String productcode;
	private Invoice invoice;
	private ItemType itemtype;
	private String sn;
	private float qty;
	private float fact_qty;
	private String bincode;
	private String result;
	private Warehouse warehouse;
	private UnitPackage unitpackage;

	
	public ItemType getItemtype() {
		return itemtype;
	}
	public void setItemtype(ItemType itemtype) {
		this.itemtype = itemtype;
	}
	public String getResult() {
		return result;
	}
	public void setResult(String result) {
		this.result = result;
	}
	public String getProductcode() {
		return productcode;
	}
	public void setProductcode(String productcode) {
		this.productcode = productcode;
	}
	public String getSn() {
		return sn;
	}
	public void setSn(String sn) {
		this.sn = sn;
	}
	public float getQty() {
		return qty;
	}
	public void setQty(float qty) {
		this.qty = qty;
	}
	public float getFact_qty() {
		return fact_qty;
	}
	public void setFact_qty(float fact_qty) {
		this.fact_qty = fact_qty;
	}
	public String getBincode() {
		return bincode;
	}
	public void setBincode(String bincode) {
		this.bincode = bincode;
	}
	public Invoice getInvoice() {
		return invoice;
	}
	public void setInvoice(Invoice invoice) {
		this.invoice = invoice;
	}
	public Warehouse getWarehouse() {
		return warehouse;
	}
	public void setWarehouse(Warehouse warehouse) {
		this.warehouse = warehouse;
	}
	public UnitPackage getUnitpackage() {
		return unitpackage;
	}
	public void setUnitpackage(UnitPackage unitpackage) {
		this.unitpackage = unitpackage;
	}

	
	

}
