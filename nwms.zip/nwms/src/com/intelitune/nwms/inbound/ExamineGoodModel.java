package com.intelitune.nwms.inbound;
/**
 * @author Louis
 *验货用到的临时Model
 */
public class ExamineGoodModel {
	private String jobId;
	private String productCode;
	private String sn;
	private float arriveQty;
	private float badQty;
	public String getJobId() {
		return jobId;
	}
	public void setJobId(String jobId) {
		this.jobId = jobId;
	}
	public String getProductCode() {
		return productCode;
	}
	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}
	public String getSn() {
		return sn;
	}
	public void setSn(String sn) {
		this.sn = sn;
	}
	public float getArriveQty() {
		return arriveQty;
	}
	public void setArriveQty(float arriveQty) {
		this.arriveQty = arriveQty;
	}
	public float getBadQty() {
		return badQty;
	}
	public void setBadQty(float badQty) {
		this.badQty = badQty;
	}
}
