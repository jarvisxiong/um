package com.intelitune.nwms.common;

public class PageURI {
	public static final String SYSTEM_ADMIN_LOGIN = "admin/userList.htm";
	
	public static final String SESSION_EXPIRED_PAGE = "../login.htm";
	
	public static final String PAGE_LOGOUT = "../login.htm?Logout=true";
	
	public static final String PAGE_WELCOME = "item/orderList.htm";
	
	public static final String PAGE_WELCOME_VENDOR = "vendor/welcomeVendor.htm";
	
	public static final String PAGE_VENDOR_LOGIN = "loginVendor.htm";
}