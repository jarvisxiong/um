package com.intelitune.nwms.common;

public class UserConst {
	public static final int LOCKED = 1;
	public static final int UNLOCKED = 0;
	
	public static final int TRUE = 0;
	public static final int FALSE = 1;
}