/**
 * BasicOrder.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.intelitune.ccos.model;

public class BasicOrder  implements java.io.Serializable {
    private java.util.Date achievementDate;

    private java.util.Date anticipateDate;

    private java.lang.String bkt;

    private com.intelitune.ccos.model.BasicOrder[] childrenOrders;

    private java.lang.String clientCode;

    private java.lang.Integer clientId;

    private java.lang.String clientName;

    private java.util.Date closeTime;

    private java.lang.Integer contactId;

    private java.lang.String contactMan;

    private java.lang.String contactPhone;

    private java.util.Date creationTime;

    private com.intelitune.ccos.model.InttUser creator;

    private java.lang.String crn;

    private java.lang.Integer id;

    private com.intelitune.ccos.model.InttJobFieldCode inttJobFieldCode;

    private com.intelitune.ccos.model.InttJobMode inttJobMode;

    private java.lang.Integer isEmergency;

    private java.lang.String jobId;

    private java.lang.Integer locked;

    private com.intelitune.ccos.model.OrderStatus orderStatus;

    private java.lang.String orderType;

    private java.lang.String rn;

    public BasicOrder() {
    }

    public BasicOrder(
           java.util.Date achievementDate,
           java.util.Date anticipateDate,
           java.lang.String bkt,
           com.intelitune.ccos.model.BasicOrder[] childrenOrders,
           java.lang.String clientCode,
           java.lang.Integer clientId,
           java.lang.String clientName,
           java.util.Date closeTime,
           java.lang.Integer contactId,
           java.lang.String contactMan,
           java.lang.String contactPhone,
           java.util.Date creationTime,
           com.intelitune.ccos.model.InttUser creator,
           java.lang.String crn,
           java.lang.Integer id,
           com.intelitune.ccos.model.InttJobFieldCode inttJobFieldCode,
           com.intelitune.ccos.model.InttJobMode inttJobMode,
           java.lang.Integer isEmergency,
           java.lang.String jobId,
           java.lang.Integer locked,
           com.intelitune.ccos.model.OrderStatus orderStatus,
           java.lang.String orderType,
           java.lang.String rn) {
           this.achievementDate = achievementDate;
           this.anticipateDate = anticipateDate;
           this.bkt = bkt;
           this.childrenOrders = childrenOrders;
           this.clientCode = clientCode;
           this.clientId = clientId;
           this.clientName = clientName;
           this.closeTime = closeTime;
           this.contactId = contactId;
           this.contactMan = contactMan;
           this.contactPhone = contactPhone;
           this.creationTime = creationTime;
           this.creator = creator;
           this.crn = crn;
           this.id = id;
           this.inttJobFieldCode = inttJobFieldCode;
           this.inttJobMode = inttJobMode;
           this.isEmergency = isEmergency;
           this.jobId = jobId;
           this.locked = locked;
           this.orderStatus = orderStatus;
           this.orderType = orderType;
           this.rn = rn;
    }


    /**
     * Gets the achievementDate value for this BasicOrder.
     * 
     * @return achievementDate
     */
    public java.util.Date getAchievementDate() {
        return achievementDate;
    }


    /**
     * Sets the achievementDate value for this BasicOrder.
     * 
     * @param achievementDate
     */
    public void setAchievementDate(java.util.Date achievementDate) {
        this.achievementDate = achievementDate;
    }


    /**
     * Gets the anticipateDate value for this BasicOrder.
     * 
     * @return anticipateDate
     */
    public java.util.Date getAnticipateDate() {
        return anticipateDate;
    }


    /**
     * Sets the anticipateDate value for this BasicOrder.
     * 
     * @param anticipateDate
     */
    public void setAnticipateDate(java.util.Date anticipateDate) {
        this.anticipateDate = anticipateDate;
    }


    /**
     * Gets the bkt value for this BasicOrder.
     * 
     * @return bkt
     */
    public java.lang.String getBkt() {
        return bkt;
    }


    /**
     * Sets the bkt value for this BasicOrder.
     * 
     * @param bkt
     */
    public void setBkt(java.lang.String bkt) {
        this.bkt = bkt;
    }


    /**
     * Gets the childrenOrders value for this BasicOrder.
     * 
     * @return childrenOrders
     */
    public com.intelitune.ccos.model.BasicOrder[] getChildrenOrders() {
        return childrenOrders;
    }


    /**
     * Sets the childrenOrders value for this BasicOrder.
     * 
     * @param childrenOrders
     */
    public void setChildrenOrders(com.intelitune.ccos.model.BasicOrder[] childrenOrders) {
        this.childrenOrders = childrenOrders;
    }


    /**
     * Gets the clientCode value for this BasicOrder.
     * 
     * @return clientCode
     */
    public java.lang.String getClientCode() {
        return clientCode;
    }


    /**
     * Sets the clientCode value for this BasicOrder.
     * 
     * @param clientCode
     */
    public void setClientCode(java.lang.String clientCode) {
        this.clientCode = clientCode;
    }


    /**
     * Gets the clientId value for this BasicOrder.
     * 
     * @return clientId
     */
    public java.lang.Integer getClientId() {
        return clientId;
    }


    /**
     * Sets the clientId value for this BasicOrder.
     * 
     * @param clientId
     */
    public void setClientId(java.lang.Integer clientId) {
        this.clientId = clientId;
    }


    /**
     * Gets the clientName value for this BasicOrder.
     * 
     * @return clientName
     */
    public java.lang.String getClientName() {
        return clientName;
    }


    /**
     * Sets the clientName value for this BasicOrder.
     * 
     * @param clientName
     */
    public void setClientName(java.lang.String clientName) {
        this.clientName = clientName;
    }


    /**
     * Gets the closeTime value for this BasicOrder.
     * 
     * @return closeTime
     */
    public java.util.Date getCloseTime() {
        return closeTime;
    }


    /**
     * Sets the closeTime value for this BasicOrder.
     * 
     * @param closeTime
     */
    public void setCloseTime(java.util.Date closeTime) {
        this.closeTime = closeTime;
    }


    /**
     * Gets the contactId value for this BasicOrder.
     * 
     * @return contactId
     */
    public java.lang.Integer getContactId() {
        return contactId;
    }


    /**
     * Sets the contactId value for this BasicOrder.
     * 
     * @param contactId
     */
    public void setContactId(java.lang.Integer contactId) {
        this.contactId = contactId;
    }


    /**
     * Gets the contactMan value for this BasicOrder.
     * 
     * @return contactMan
     */
    public java.lang.String getContactMan() {
        return contactMan;
    }


    /**
     * Sets the contactMan value for this BasicOrder.
     * 
     * @param contactMan
     */
    public void setContactMan(java.lang.String contactMan) {
        this.contactMan = contactMan;
    }


    /**
     * Gets the contactPhone value for this BasicOrder.
     * 
     * @return contactPhone
     */
    public java.lang.String getContactPhone() {
        return contactPhone;
    }


    /**
     * Sets the contactPhone value for this BasicOrder.
     * 
     * @param contactPhone
     */
    public void setContactPhone(java.lang.String contactPhone) {
        this.contactPhone = contactPhone;
    }


    /**
     * Gets the creationTime value for this BasicOrder.
     * 
     * @return creationTime
     */
    public java.util.Date getCreationTime() {
        return creationTime;
    }


    /**
     * Sets the creationTime value for this BasicOrder.
     * 
     * @param creationTime
     */
    public void setCreationTime(java.util.Date creationTime) {
        this.creationTime = creationTime;
    }


    /**
     * Gets the creator value for this BasicOrder.
     * 
     * @return creator
     */
    public com.intelitune.ccos.model.InttUser getCreator() {
        return creator;
    }


    /**
     * Sets the creator value for this BasicOrder.
     * 
     * @param creator
     */
    public void setCreator(com.intelitune.ccos.model.InttUser creator) {
        this.creator = creator;
    }


    /**
     * Gets the crn value for this BasicOrder.
     * 
     * @return crn
     */
    public java.lang.String getCrn() {
        return crn;
    }


    /**
     * Sets the crn value for this BasicOrder.
     * 
     * @param crn
     */
    public void setCrn(java.lang.String crn) {
        this.crn = crn;
    }


    /**
     * Gets the id value for this BasicOrder.
     * 
     * @return id
     */
    public java.lang.Integer getId() {
        return id;
    }


    /**
     * Sets the id value for this BasicOrder.
     * 
     * @param id
     */
    public void setId(java.lang.Integer id) {
        this.id = id;
    }


    /**
     * Gets the inttJobFieldCode value for this BasicOrder.
     * 
     * @return inttJobFieldCode
     */
    public com.intelitune.ccos.model.InttJobFieldCode getInttJobFieldCode() {
        return inttJobFieldCode;
    }


    /**
     * Sets the inttJobFieldCode value for this BasicOrder.
     * 
     * @param inttJobFieldCode
     */
    public void setInttJobFieldCode(com.intelitune.ccos.model.InttJobFieldCode inttJobFieldCode) {
        this.inttJobFieldCode = inttJobFieldCode;
    }


    /**
     * Gets the inttJobMode value for this BasicOrder.
     * 
     * @return inttJobMode
     */
    public com.intelitune.ccos.model.InttJobMode getInttJobMode() {
        return inttJobMode;
    }


    /**
     * Sets the inttJobMode value for this BasicOrder.
     * 
     * @param inttJobMode
     */
    public void setInttJobMode(com.intelitune.ccos.model.InttJobMode inttJobMode) {
        this.inttJobMode = inttJobMode;
    }


    /**
     * Gets the isEmergency value for this BasicOrder.
     * 
     * @return isEmergency
     */
    public java.lang.Integer getIsEmergency() {
        return isEmergency;
    }


    /**
     * Sets the isEmergency value for this BasicOrder.
     * 
     * @param isEmergency
     */
    public void setIsEmergency(java.lang.Integer isEmergency) {
        this.isEmergency = isEmergency;
    }


    /**
     * Gets the jobId value for this BasicOrder.
     * 
     * @return jobId
     */
    public java.lang.String getJobId() {
        return jobId;
    }


    /**
     * Sets the jobId value for this BasicOrder.
     * 
     * @param jobId
     */
    public void setJobId(java.lang.String jobId) {
        this.jobId = jobId;
    }


    /**
     * Gets the locked value for this BasicOrder.
     * 
     * @return locked
     */
    public java.lang.Integer getLocked() {
        return locked;
    }


    /**
     * Sets the locked value for this BasicOrder.
     * 
     * @param locked
     */
    public void setLocked(java.lang.Integer locked) {
        this.locked = locked;
    }


    /**
     * Gets the orderStatus value for this BasicOrder.
     * 
     * @return orderStatus
     */
    public com.intelitune.ccos.model.OrderStatus getOrderStatus() {
        return orderStatus;
    }


    /**
     * Sets the orderStatus value for this BasicOrder.
     * 
     * @param orderStatus
     */
    public void setOrderStatus(com.intelitune.ccos.model.OrderStatus orderStatus) {
        this.orderStatus = orderStatus;
    }


    /**
     * Gets the orderType value for this BasicOrder.
     * 
     * @return orderType
     */
    public java.lang.String getOrderType() {
        return orderType;
    }


    /**
     * Sets the orderType value for this BasicOrder.
     * 
     * @param orderType
     */
    public void setOrderType(java.lang.String orderType) {
        this.orderType = orderType;
    }


    /**
     * Gets the rn value for this BasicOrder.
     * 
     * @return rn
     */
    public java.lang.String getRn() {
        return rn;
    }


    /**
     * Sets the rn value for this BasicOrder.
     * 
     * @param rn
     */
    public void setRn(java.lang.String rn) {
        this.rn = rn;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof BasicOrder)) return false;
        BasicOrder other = (BasicOrder) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.achievementDate==null && other.getAchievementDate()==null) || 
             (this.achievementDate!=null &&
              this.achievementDate.equals(other.getAchievementDate()))) &&
            ((this.anticipateDate==null && other.getAnticipateDate()==null) || 
             (this.anticipateDate!=null &&
              this.anticipateDate.equals(other.getAnticipateDate()))) &&
            ((this.bkt==null && other.getBkt()==null) || 
             (this.bkt!=null &&
              this.bkt.equals(other.getBkt()))) &&
            ((this.childrenOrders==null && other.getChildrenOrders()==null) || 
             (this.childrenOrders!=null &&
              java.util.Arrays.equals(this.childrenOrders, other.getChildrenOrders()))) &&
            ((this.clientCode==null && other.getClientCode()==null) || 
             (this.clientCode!=null &&
              this.clientCode.equals(other.getClientCode()))) &&
            ((this.clientId==null && other.getClientId()==null) || 
             (this.clientId!=null &&
              this.clientId.equals(other.getClientId()))) &&
            ((this.clientName==null && other.getClientName()==null) || 
             (this.clientName!=null &&
              this.clientName.equals(other.getClientName()))) &&
            ((this.closeTime==null && other.getCloseTime()==null) || 
             (this.closeTime!=null &&
              this.closeTime.equals(other.getCloseTime()))) &&
            ((this.contactId==null && other.getContactId()==null) || 
             (this.contactId!=null &&
              this.contactId.equals(other.getContactId()))) &&
            ((this.contactMan==null && other.getContactMan()==null) || 
             (this.contactMan!=null &&
              this.contactMan.equals(other.getContactMan()))) &&
            ((this.contactPhone==null && other.getContactPhone()==null) || 
             (this.contactPhone!=null &&
              this.contactPhone.equals(other.getContactPhone()))) &&
            ((this.creationTime==null && other.getCreationTime()==null) || 
             (this.creationTime!=null &&
              this.creationTime.equals(other.getCreationTime()))) &&
            ((this.creator==null && other.getCreator()==null) || 
             (this.creator!=null &&
              this.creator.equals(other.getCreator()))) &&
            ((this.crn==null && other.getCrn()==null) || 
             (this.crn!=null &&
              this.crn.equals(other.getCrn()))) &&
            ((this.id==null && other.getId()==null) || 
             (this.id!=null &&
              this.id.equals(other.getId()))) &&
            ((this.inttJobFieldCode==null && other.getInttJobFieldCode()==null) || 
             (this.inttJobFieldCode!=null &&
              this.inttJobFieldCode.equals(other.getInttJobFieldCode()))) &&
            ((this.inttJobMode==null && other.getInttJobMode()==null) || 
             (this.inttJobMode!=null &&
              this.inttJobMode.equals(other.getInttJobMode()))) &&
            ((this.isEmergency==null && other.getIsEmergency()==null) || 
             (this.isEmergency!=null &&
              this.isEmergency.equals(other.getIsEmergency()))) &&
            ((this.jobId==null && other.getJobId()==null) || 
             (this.jobId!=null &&
              this.jobId.equals(other.getJobId()))) &&
            ((this.locked==null && other.getLocked()==null) || 
             (this.locked!=null &&
              this.locked.equals(other.getLocked()))) &&
            ((this.orderStatus==null && other.getOrderStatus()==null) || 
             (this.orderStatus!=null &&
              this.orderStatus.equals(other.getOrderStatus()))) &&
            ((this.orderType==null && other.getOrderType()==null) || 
             (this.orderType!=null &&
              this.orderType.equals(other.getOrderType()))) &&
            ((this.rn==null && other.getRn()==null) || 
             (this.rn!=null &&
              this.rn.equals(other.getRn())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getAchievementDate() != null) {
            _hashCode += getAchievementDate().hashCode();
        }
        if (getAnticipateDate() != null) {
            _hashCode += getAnticipateDate().hashCode();
        }
        if (getBkt() != null) {
            _hashCode += getBkt().hashCode();
        }
        if (getChildrenOrders() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getChildrenOrders());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getChildrenOrders(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getClientCode() != null) {
            _hashCode += getClientCode().hashCode();
        }
        if (getClientId() != null) {
            _hashCode += getClientId().hashCode();
        }
        if (getClientName() != null) {
            _hashCode += getClientName().hashCode();
        }
        if (getCloseTime() != null) {
            _hashCode += getCloseTime().hashCode();
        }
        if (getContactId() != null) {
            _hashCode += getContactId().hashCode();
        }
        if (getContactMan() != null) {
            _hashCode += getContactMan().hashCode();
        }
        if (getContactPhone() != null) {
            _hashCode += getContactPhone().hashCode();
        }
        if (getCreationTime() != null) {
            _hashCode += getCreationTime().hashCode();
        }
        if (getCreator() != null) {
            _hashCode += getCreator().hashCode();
        }
        if (getCrn() != null) {
            _hashCode += getCrn().hashCode();
        }
        if (getId() != null) {
            _hashCode += getId().hashCode();
        }
        if (getInttJobFieldCode() != null) {
            _hashCode += getInttJobFieldCode().hashCode();
        }
        if (getInttJobMode() != null) {
            _hashCode += getInttJobMode().hashCode();
        }
        if (getIsEmergency() != null) {
            _hashCode += getIsEmergency().hashCode();
        }
        if (getJobId() != null) {
            _hashCode += getJobId().hashCode();
        }
        if (getLocked() != null) {
            _hashCode += getLocked().hashCode();
        }
        if (getOrderStatus() != null) {
            _hashCode += getOrderStatus().hashCode();
        }
        if (getOrderType() != null) {
            _hashCode += getOrderType().hashCode();
        }
        if (getRn() != null) {
            _hashCode += getRn().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(BasicOrder.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://model.ccos.intelitune.com", "BasicOrder"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("achievementDate");
        elemField.setXmlName(new javax.xml.namespace.QName("http://model.ccos.intelitune.com", "achievementDate"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "dateTime"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("anticipateDate");
        elemField.setXmlName(new javax.xml.namespace.QName("http://model.ccos.intelitune.com", "anticipateDate"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "dateTime"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("bkt");
        elemField.setXmlName(new javax.xml.namespace.QName("http://model.ccos.intelitune.com", "bkt"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("childrenOrders");
        elemField.setXmlName(new javax.xml.namespace.QName("http://model.ccos.intelitune.com", "childrenOrders"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://model.ccos.intelitune.com", "BasicOrder"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        elemField.setItemQName(new javax.xml.namespace.QName("http://model.ccos.intelitune.com", "BasicOrder"));
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("clientCode");
        elemField.setXmlName(new javax.xml.namespace.QName("http://model.ccos.intelitune.com", "clientCode"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("clientId");
        elemField.setXmlName(new javax.xml.namespace.QName("http://model.ccos.intelitune.com", "clientId"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("clientName");
        elemField.setXmlName(new javax.xml.namespace.QName("http://model.ccos.intelitune.com", "clientName"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("closeTime");
        elemField.setXmlName(new javax.xml.namespace.QName("http://model.ccos.intelitune.com", "closeTime"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "dateTime"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("contactId");
        elemField.setXmlName(new javax.xml.namespace.QName("http://model.ccos.intelitune.com", "contactId"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("contactMan");
        elemField.setXmlName(new javax.xml.namespace.QName("http://model.ccos.intelitune.com", "contactMan"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("contactPhone");
        elemField.setXmlName(new javax.xml.namespace.QName("http://model.ccos.intelitune.com", "contactPhone"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("creationTime");
        elemField.setXmlName(new javax.xml.namespace.QName("http://model.ccos.intelitune.com", "creationTime"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "dateTime"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("creator");
        elemField.setXmlName(new javax.xml.namespace.QName("http://model.ccos.intelitune.com", "creator"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://model.ccos.intelitune.com", "InttUser"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("crn");
        elemField.setXmlName(new javax.xml.namespace.QName("http://model.ccos.intelitune.com", "crn"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("id");
        elemField.setXmlName(new javax.xml.namespace.QName("http://model.ccos.intelitune.com", "id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("inttJobFieldCode");
        elemField.setXmlName(new javax.xml.namespace.QName("http://model.ccos.intelitune.com", "inttJobFieldCode"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://model.ccos.intelitune.com", "InttJobFieldCode"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("inttJobMode");
        elemField.setXmlName(new javax.xml.namespace.QName("http://model.ccos.intelitune.com", "inttJobMode"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://model.ccos.intelitune.com", "InttJobMode"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("isEmergency");
        elemField.setXmlName(new javax.xml.namespace.QName("http://model.ccos.intelitune.com", "isEmergency"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("jobId");
        elemField.setXmlName(new javax.xml.namespace.QName("http://model.ccos.intelitune.com", "jobId"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("locked");
        elemField.setXmlName(new javax.xml.namespace.QName("http://model.ccos.intelitune.com", "locked"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("orderStatus");
        elemField.setXmlName(new javax.xml.namespace.QName("http://model.ccos.intelitune.com", "orderStatus"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://model.ccos.intelitune.com", "OrderStatus"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("orderType");
        elemField.setXmlName(new javax.xml.namespace.QName("http://model.ccos.intelitune.com", "orderType"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("rn");
        elemField.setXmlName(new javax.xml.namespace.QName("http://model.ccos.intelitune.com", "rn"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
