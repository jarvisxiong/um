/**
 * WMSServicePortType.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.intelitune.ccos.client;

public interface WMSServicePortType extends java.rmi.Remote {
    public boolean closeSession(java.lang.Object in0) throws java.rmi.RemoteException;
    public com.intelitune.ccos.model.WmsOrder[] findAll() throws java.rmi.RemoteException;
    public com.intelitune.ccos.model.WmsOrder findByJobId(java.lang.String in0) throws java.rmi.RemoteException;
    public boolean refWmsOrder(com.intelitune.ccos.model.WmsOrder in0, java.lang.String in1) throws java.rmi.RemoteException;
    public boolean save(java.lang.Object in0) throws java.rmi.RemoteException;
    public java.lang.Object[] query(java.lang.String in0) throws java.rmi.RemoteException;
    public boolean update(java.lang.String in0) throws java.rmi.RemoteException;
    public com.intelitune.ccos.model.WmsOrder findById(int in0) throws java.rmi.RemoteException;
    public com.intelitune.ccos.model.WmsOrder[] queryWmsOrder(java.lang.String in0) throws java.rmi.RemoteException;
    public boolean deRefWmsOrder(com.intelitune.ccos.model.WmsOrder in0, java.lang.String in1) throws java.rmi.RemoteException;
}
