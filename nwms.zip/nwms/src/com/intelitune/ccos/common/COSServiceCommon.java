/**
 * COSServiceCommon.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.intelitune.ccos.common;

public interface COSServiceCommon extends javax.xml.rpc.Service {
    public java.lang.String getCOSServiceCommonHttpPortAddress();

    public com.intelitune.ccos.common.COSServiceCommonPortType getCOSServiceCommonHttpPort() throws javax.xml.rpc.ServiceException;

    public com.intelitune.ccos.common.COSServiceCommonPortType getCOSServiceCommonHttpPort(java.net.URL portAddress) throws javax.xml.rpc.ServiceException;
}
