package com.intelitune.ccos.test;

import java.io.IOException;
import java.util.Iterator;
import java.util.List;

import net.sf.click.Page;

import com.intelitune.nwms.model.ItemState;

public class Test4 extends Page
{
public void onRender(){
    String s = "{     \"list of lists\" : [         [1, 2, 3],         [4, 5, 6],     ] }";
}

}
