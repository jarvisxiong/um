package com.intelitune.export;

public interface DataSource {
	
	public boolean first() throws Exception;
	public boolean next() throws Exception;
	
	public Object getBean() throws Exception;

}
