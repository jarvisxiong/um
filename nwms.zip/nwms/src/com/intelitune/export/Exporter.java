package com.intelitune.export;

import java.util.Collection;
import java.util.Map;


/*
 * 
 */
public interface Exporter {
	
	//user can select template, generate Document name
	public String generate(Template template, DataSource dataSource, Map map, Document document) throws Exception;
	public String generate(Template template, Collection collection, Map map, Document document) throws Exception;

}
