package com.intelitune.export;

import java.util.Collection;
import java.util.Map;

public interface ExporterInbound {
//	public String generate(Template template, DataSource dataSource, Map map, Document document) throws Exception;
	public String generate(Template template, Collection collection1,Collection collection2, Map map, Document document) throws Exception;

}
