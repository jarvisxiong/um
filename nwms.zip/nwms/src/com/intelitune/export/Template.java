package com.intelitune.export;


import java.util.Collection;
import java.util.Map;

public interface Template {
	// Exporter callback this mothod export document

	public void export(Map map, Collection collection, Document docuemnt) throws Exception;
	
	public void export(Map map, Collection collection1,Collection collection2, Document docuemnt) throws Exception;

	// get template path
	public String getPath();

	// set template path
	public void setPath(String path);

	// get template name
	public String getName();

	// set template name
	public void setName(String name);
}
