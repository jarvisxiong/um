alter table intt_invoice RENAME COLUMN so TO po1

alter table intt_invoice RENAME COLUMN po TO so

alter table intt_invoice RENAME COLUMN po1 TO po
