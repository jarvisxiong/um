alter table intt_item add(intt_outbound_invoice_id varchar2(255 char));

alter table intt_item add constraint FK368404AD72537861 foreign key (intt_outbound_invoice_id) references intt_invoice;