alter table intt_invoice add(so VARCHAR2(255 char));
alter table intt_invoice add(po VARCHAR2(255 char));