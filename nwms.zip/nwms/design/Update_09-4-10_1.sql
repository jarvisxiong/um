--有用
alter table intt_warehouseItem add(intt_crn VARCHAR2(255 char));